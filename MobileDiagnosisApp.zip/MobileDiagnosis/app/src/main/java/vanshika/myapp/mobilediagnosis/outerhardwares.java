package vanshika.myapp.mobilediagnosis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class outerhardwares extends AppCompatActivity {


    public void network(View view){
        Intent in1= new Intent(outerhardwares.this,network.class);

        startActivity(in1);
    }
    public void display(View view){
        Intent in1= new Intent(outerhardwares.this,display.class);

        startActivity(in1);
    }
    public void flash(View view){
        Intent in1= new Intent(outerhardwares.this,flash.class);

        startActivity(in1);
    }
    public void home(View view){
        Intent in1= new Intent(outerhardwares.this,home.class);

        startActivity(in1);
    }
    public void camera(View view){
        Intent in1= new Intent(outerhardwares.this,camera.class);

        startActivity(in1);
    }

    public void receiver(View view){
        Intent in1= new Intent(outerhardwares.this,receiver.class);

        startActivity(in1);
    }
    public void location(View view){
        Intent in1= new Intent(outerhardwares.this,location.class);

        startActivity(in1);
    }
    public void power(View view){
        Intent in1= new Intent(outerhardwares.this,power.class);

        startActivity(in1);
    }
    public void acc(View view){
        Intent in1= new Intent(outerhardwares.this,acc.class);

        startActivity(in1);
    }
    public void fingerprint(View view){
        Intent in1= new Intent(outerhardwares.this,fingerprint.class);

        startActivity(in1);
    }
    public void faceid(View view){
        Intent in1= new Intent(outerhardwares.this,faceid.class);

        startActivity(in1);
    }

    public void bt(View view){
        Intent in1= new Intent(outerhardwares.this,bt.class);

        startActivity(in1);
    }
    public void vibrate(View view){
        Intent in1= new Intent(outerhardwares.this,vibrate.class);

        startActivity(in1);
    }
    public void speaker(View view){
        Intent in1= new Intent(outerhardwares.this,speaker.class);

        startActivity(in1);
    }
    public void volume(View view){
        Intent in1= new Intent(outerhardwares.this,volume.class);

        startActivity(in1);
    }
    public void earphones(View view){
        Intent in1= new Intent(outerhardwares.this,earphones.class);

        startActivity(in1);
    }

    public void multitouch(View view){
        Intent in1= new Intent(outerhardwares.this,multitouch.class);

        startActivity(in1);
    }
    public void air(View view){
        Intent in1= new Intent(outerhardwares.this, air.class);

        startActivity(in1);
    }

    public void proximity(View view){
        Intent in1= new Intent(outerhardwares.this,proximitysensor.class);

        startActivity(in1);
    }
    public void motion(View view){
        Intent in1= new Intent(outerhardwares.this,motion.class);

        startActivity(in1);
    }
    public void wifi(View view){
        Intent in1= new Intent(outerhardwares.this, sim.class);

        startActivity(in1);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_outerhardwares);
        Intent i=getIntent();
    }
}