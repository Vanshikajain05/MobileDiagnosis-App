package vanshika.myapp.mobilediagnosis;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityManager;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.NumberFormat;


public class innerhardwares extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_innerhardwares);
        Intent i = getIntent();


        TextView mm = (TextView) findViewById(R.id.intmem);
        mm.setText("Total ROM: "+formatSize(getTIMS())+"\n"+"Free ROM: " +
                ""+formatSize(getAIMS())+"\n"+"Used ROM: "+formatSize(getUsedIntMemory()));
        TextView kv = (TextView) findViewById(R.id.t1);
        kv.setText("Kernel Version "+"\n"+"\n"+getKernelVersion());

        TextView r= (TextView)findViewById(R.id.ram);

        ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo Mi=new ActivityManager.MemoryInfo();
       am.getMemoryInfo(Mi);
       float totalmem= Mi.totalMem/(1024*1024);
       float freeMem= Mi.availMem/(1024*1024);
       float usedMem= totalmem-freeMem;

       float freep=freeMem/totalmem*100;
       float usedp= usedMem/totalmem*100;

        NumberFormat nfree=NumberFormat.getNumberInstance();
        nfree.setMinimumFractionDigits(1);
        nfree.setMinimumFractionDigits(1);
        String free=nfree.format(freep);

        NumberFormat nused=NumberFormat.getNumberInstance();
        nused.setMinimumFractionDigits(1);
        nused.setMinimumFractionDigits(1);
        String used=nfree.format(usedp);

        r.setText("Total RAM: "+totalmem+"MB"+"\n"+"Used RAM: "+usedMem+"MB"+"("+used+"%)"+"\n"+"Free RAM: "+freeMem+"MB"+"("+free+"%)");
    }

public void cpuinfo(View view){
    Intent in1= new Intent(innerhardwares.this,cpu.class);

    startActivity(in1);
}

    public static String getKernelVersion() {
        try {
            Process p = Runtime.getRuntime().exec("uname -a");
            InputStream is = null;
            if (p.waitFor() == 0) {
                is = p.getInputStream();
            } else {
                is = p.getErrorStream();
            }
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String line = br.readLine();
            Log.i("Kernel Version", line);
            br.close();
            return line;
        } catch (Exception ex) {
            return "ERROR: " + ex.getMessage();
        }
    }
    public long getTIMS() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long BlockSize = stat.getBlockSize();
        long TotalBlocks = stat.getBlockCount();
        return (TotalBlocks * BlockSize);
    }
    public long getAIMS() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSize();
        long availableBlocks = stat.getAvailableBlocks();
        return (availableBlocks * blockSize);
    }

    public long getUsedIntMemory(){
        long t=getTIMS();
        long a=getAIMS();
        long u=t-a;
        return u;
    }

    public static String formatSize(long size) {
        String suffixSize = null;

        if (size >= 1024) {
            suffixSize = "KB";
            size /= 1024;
            if (size >= 1024) {
                suffixSize = "MB";
                size /= 1024;
            }

        }

        StringBuilder BufferSize = new StringBuilder(
                Long.toString(size));

        int commaOffset = BufferSize.length() - 3;
        while (commaOffset > 0) {
            BufferSize.insert(commaOffset, ',');
            commaOffset -= 3;
        }

        if (suffixSize != null) BufferSize.append(suffixSize);
        return BufferSize.toString();
    }


}