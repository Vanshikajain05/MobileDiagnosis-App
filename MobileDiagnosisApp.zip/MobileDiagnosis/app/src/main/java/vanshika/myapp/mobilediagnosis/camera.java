package vanshika.myapp.mobilediagnosis;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class camera extends AppCompatActivity {

public static final int req=9;
ImageView im;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);
        Intent i=getIntent();
      im=(ImageView)findViewById(R.id.image);

    }

    public void open(View view){
     Intent in=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
     startActivityForResult(in,req);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==req){
            Bitmap bm=(Bitmap) data.getExtras().get("data");
            im.setImageBitmap(bm);
            Toast.makeText(this, "Camera is working fine!!", Toast.LENGTH_LONG).show();
        }
    }
}