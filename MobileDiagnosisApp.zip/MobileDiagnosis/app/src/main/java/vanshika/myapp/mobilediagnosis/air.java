package vanshika.myapp.mobilediagnosis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class air extends AppCompatActivity {

    TextView textView;
    ImageView im;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.air);
        Intent i=getIntent();
        textView=(TextView)findViewById(R.id.t);
        im=(ImageView)findViewById(R.id.im);

    }
    public void mode(View view){
        checkAirplaneMode();
    }
    private void checkAirplaneMode() {
        if (isAirplaneModeOn(getApplicationContext())) {
            textView.setText("Airplane Mode is Enabled!");
            im.setImageResource(R.drawable.enable);

        } else {
            textView.setText("Airplane Mode is Disabled!");
            im.setImageResource(R.drawable.disable);
        }
    }
    private static boolean isAirplaneModeOn(Context context) {
        return Settings.System.getInt(context.getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0) != 0;
    }
}