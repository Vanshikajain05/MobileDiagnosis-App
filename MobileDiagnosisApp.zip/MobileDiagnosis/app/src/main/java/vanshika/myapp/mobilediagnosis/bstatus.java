package vanshika.myapp.mobilediagnosis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

public class bstatus extends AppCompatActivity {

    private BatteryReceiver br=new BatteryReceiver();
    private IntentFilter inf= new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bstatus);
        Intent i=getIntent();
    }

    @Override
    protected void onResume(){
        super.onResume();
        registerReceiver(br,inf);
    }
@Override
    protected void onPause(){

        unregisterReceiver(br);
    super.onPause();
    }
}