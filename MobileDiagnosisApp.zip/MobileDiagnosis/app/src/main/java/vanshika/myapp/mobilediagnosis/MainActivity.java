package vanshika.myapp.mobilediagnosis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public void fade(View view){
        Intent in1= new Intent(MainActivity.this,choosehardware.class);

        startActivity(in1);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView ig = (ImageView) findViewById(R.id.imageView);
        ig.setX(-1000);
        ig.animate().translationXBy(900).rotationXBy(360).setDuration(1000);

        TextView t1=(TextView)findViewById(R.id.text);
        t1.setX(-1000);
        t1.animate().translationXBy(1000).setDuration(2000);
        TextView t=(TextView)findViewById(R.id.textt);
        t.setX(-1000);
        t.animate().translationXBy(1000).setDuration(2000);

    }
}