package vanshika.myapp.mobilediagnosis;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View;

import java.text.DecimalFormat;

public class mobileinfo extends AppCompatActivity {

    public void batterystatus(View view){
        Intent in1= new Intent(mobileinfo.this,bstatus.class);

        startActivity(in1);
    }
public void deviceinfo(View view){
    Intent in1= new Intent(mobileinfo.this,deviceinfo.class);

    startActivity(in1);
}
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mobileinfo);
        Intent i=getIntent();

        }
    }
