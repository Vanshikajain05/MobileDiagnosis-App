package vanshika.myapp.mobilediagnosis;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;

public class location extends AppCompatActivity implements LocationListener {

    TextView country;
    TextView state;
    TextView city;
    TextView location;
    LocationManager lm;
    private double lat;
    private double longitude;

    public void getLoc(View view) {
        //Toast.makeText(this, "GPS is working!", Toast.LENGTH_SHORT).show();
        country = (TextView) findViewById(R.id.gps);
        state = (TextView) findViewById(R.id.state);
        city = (TextView) findViewById(R.id.post);
        location = (TextView) findViewById(R.id.loc);


        //Access permissions
        if (ContextCompat.checkSelfPermission(location.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(location.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        } else {
            detectCurrentLocation();
        }
    }

    private void detectCurrentLocation() {
        //allow or deny to enable gps
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);
        Intent i=getIntent();
        //Toast.makeText(this, "GPS is working fine!", Toast.LENGTH_SHORT).show();
    }

    private void findAddress() {
        Geocoder geo;
        List<Address> ad;
        geo=new Geocoder(this, Locale.getDefault());

        try{
            ad=geo.getFromLocation(lat,longitude,1);
            String c=ad.get(0).getCountryName();
            String s=ad.get(0).getAdminArea();
            String p= ad.get(0).getLocality();
            String a=ad.get(0).getAddressLine(0);

            country.setText("Country: "+c);
            state.setText("State: "+s);
            city.setText("City: "+p);
            location.setText("Location: "+a);


        }
        catch(Exception e){

        }

    }

    @Override
    public void onLocationChanged(Location location) {
        lat=location.getLatitude();
        longitude=location.getLongitude();
        findAddress();
    }

    @Override
    public void onProviderEnabled(@NonNull String provider) {

    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {
        Toast.makeText(this, "Please turn on location", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
       if(requestCode==1){
           if(grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED){
               detectCurrentLocation();
           }
           else {
               detectCurrentLocation();
           }
       }
    }
}