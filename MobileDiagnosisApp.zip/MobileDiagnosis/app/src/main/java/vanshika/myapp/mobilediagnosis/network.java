package vanshika.myapp.mobilediagnosis;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Enumeration;

public class network extends AppCompatActivity {
//ISP REGION PING FREQUENCY
    ImageView im;
    TextView tt;
    TextView tt2;
    TextView tt3;
    TextView tt4;
    TextView tt5;
    TextView tt6;
    TextView tt7;
    Button bt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_network);
        Intent i=getIntent();
        im=(ImageView)findViewById(R.id.im);
        tt=(TextView)findViewById(R.id.text);
        tt2=(TextView)findViewById(R.id.text2);
        tt3=(TextView)findViewById(R.id.text3);
        tt4=(TextView)findViewById(R.id.text4);
        tt5=(TextView)findViewById(R.id.text5);
        tt6=(TextView)findViewById(R.id.text6);
        tt7=(TextView)findViewById(R.id.text7);
        bt=(Button)findViewById(R.id.button);
        bt.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View view) {
                checkstatus();
                publicip();
            }
        });
    }

    private void publicip(){
        try {
            StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            URL ip=new URL("https://checkip.amazonaws.com/");
            URLConnection connection=ip.openConnection();
            connection.setConnectTimeout(1000);
            connection.setReadTimeout(1000);

            BufferedReader bf=new BufferedReader(new InputStreamReader(connection.getInputStream()));
            tt5.setText("Public IP: "+bf.readLine());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
       @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
       private void checkstatus(){


           boolean wifi;
           boolean mobile;
           ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
           NetworkInfo activeinfo=cm.getActiveNetworkInfo();
           if (activeinfo != null && activeinfo.isConnected()) {

               wifi=activeinfo.getType()==ConnectivityManager.TYPE_WIFI;
               mobile=activeinfo.getType()==ConnectivityManager.TYPE_MOBILE;
               if(wifi){
                im.setImageResource(R.drawable.ic_baseline_wifi_24);
                tt.setText("Network Status: Wifi Connected ");
               }
               else if(mobile){
                   im.setImageResource(R.drawable.ic_baseline_compare_arrows_24);
                   tt.setText("Network Status: Mobile Data Connected ");
               }
           }
           else{
               im.setImageResource(R.drawable.ic_baseline_not_interested_24);
               tt.setText("Network Status: No internet connection ");
           }

           WifiManager wm=(WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);
           WifiInfo in=wm.getConnectionInfo();
           String macaddress=in.getMacAddress();
           String ssid=in.getSSID();
           int speed=wm.getConnectionInfo().getLinkSpeed();
           int freq=wm.getConnectionInfo().getFrequency();
           tt2.setText("MAC Address: "+macaddress);
           tt3.setText("Local IP: "+getLocalIP());
           tt4.setText("SSID: "+ssid);
           tt6.setText("WIFI Frequency: "+freq+"MHz");
           tt7.setText("Link Speed: "+speed);

    }
    public static String getLocalIP() {
        try {
            for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); ((Enumeration) en).hasMoreElements();) {
                NetworkInterface intf = en.nextElement();
                for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements();) {
                    InetAddress inetAddress = enumIpAddr.nextElement();
                    if (!inetAddress.isLoopbackAddress() && inetAddress instanceof Inet4Address) {
                        return inetAddress.getHostAddress();
                    }
                }
            }
        } catch (SocketException ex) {
            ex.printStackTrace();
        }
        return null;
    }




}