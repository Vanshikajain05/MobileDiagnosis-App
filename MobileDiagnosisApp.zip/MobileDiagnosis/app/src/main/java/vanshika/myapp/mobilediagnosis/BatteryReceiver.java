package vanshika.myapp.mobilediagnosis;

import android.annotation.TargetApi;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.BatteryManager;
import android.os.Build;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class BatteryReceiver extends BroadcastReceiver {


    @TargetApi(Build.VERSION_CODES.LOLLIPOP)

    public long getBatteryCapacity(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            BatteryManager mBatteryManager = (BatteryManager) context.getSystemService(Context.BATTERY_SERVICE);
            Long chargeCounter = mBatteryManager.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);
            Long capacity = mBatteryManager.getLongProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);

            if (chargeCounter != null && capacity != null) {
                long value = (long) (((float) chargeCounter / (float) capacity) * 100f);
                return value;
            }
        }

        return 0;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        TextView text = ((bstatus) context).findViewById(R.id.text);
        TextView tt2 = ((bstatus) context).findViewById(R.id.tt2);
        TextView statuslabel = ((bstatus) context).findViewById(R.id.charging);
        TextView plabel = ((bstatus) context).findViewById(R.id.percent);
        ImageView im = ((bstatus) context).findViewById(R.id.level);
        String action = intent.getAction();
        if (action != null && action.equals(Intent.ACTION_BATTERY_CHANGED)) {

            int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            String msg = "";

            switch (status) {

                case BatteryManager.BATTERY_STATUS_FULL:
                    msg = "Full";
                    break;

                case BatteryManager.BATTERY_STATUS_CHARGING:
                    msg = "Charging";
                    break;

                case BatteryManager.BATTERY_STATUS_NOT_CHARGING:
                    msg = "Not charging";
                    break;
                case BatteryManager.BATTERY_STATUS_DISCHARGING:
                    msg = "Discharging";
                    break;
                case BatteryManager.BATTERY_STATUS_UNKNOWN:
                    msg = "Unknown";
                    break;
            }

            statuslabel.setText(msg);

            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);

            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            int percentage = level * 100 / scale;
            plabel.setText(percentage + "%");

            Resources res = context.getResources();

            if (percentage >= 90) {
                im.setImageDrawable(res.getDrawable(R.drawable.hundred));
            } else if (90 > percentage && percentage >= 65) {
                im.setImageDrawable(res.getDrawable(R.drawable.seventyfive));

            } else if (65 > percentage && percentage >= 40) {
                im.setImageDrawable(res.getDrawable(R.drawable.fifty));
            } else if (40 > percentage && percentage >= 15) {
                im.setImageDrawable(res.getDrawable(R.drawable.twentyfive));
            } else {
                im.setImageDrawable(res.getDrawable(R.drawable.zero));
            }
        }


        int health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, 0);
        String msg = "";
        //unknown=1 good=2 overheated=3 bad=4 overvoltage-5 failed=6
        switch (health) {

            case BatteryManager.BATTERY_HEALTH_GOOD:
                msg = "Good";
                break;

            case BatteryManager.BATTERY_HEALTH_OVERHEAT:
                msg = "Overheat";
                break;

            case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE:
                msg = "Over-voltage";
                break;
            case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE:
                msg = "Failed";
                break;
            case BatteryManager.BATTERY_STATUS_UNKNOWN:
                msg = "Unknown";
                break;

        }
        //power source  none-0 ac charger-1 usb-2
        int plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
        String msg2 = "";

        switch (plugged) {

            case BatteryManager.BATTERY_PLUGGED_AC:
                msg2 = "AC Charger";
                break;

            case BatteryManager.BATTERY_PLUGGED_USB:
                msg2 = "USB Plugged ";
                break;

            case BatteryManager.BATTERY_PLUGGED_WIRELESS:
                msg2 = "None";
                break;


        }
        String tech = intent.getExtras().getString(BatteryManager.EXTRA_TECHNOLOGY);

        long capacity = getBatteryCapacity(context);

        if (capacity > 0) {
            tt2.setText("Capacity : " + capacity + " mAh");
        }

    else
    {
        Toast.makeText(context, "No battery found", Toast.LENGTH_SHORT).show();
    }
        int temp= intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,0);
        int voltage=intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE,0);
text.setText("Health: "+msg+"\n"+"Plugged: "+msg2+"\n"+"Technology :"+tech+"\n"+"Temperature: "+temp+"\n"+"Voltage: "+voltage+"mV");


    }


}
