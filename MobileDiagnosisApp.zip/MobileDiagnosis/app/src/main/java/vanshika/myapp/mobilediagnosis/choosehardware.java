package vanshika.myapp.mobilediagnosis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class choosehardware extends AppCompatActivity {

    public void outerhardwares(View view){
        Intent in1= new Intent(choosehardware.this,outerhardwares.class);

        startActivity(in1);
    }
    public void innerhardwares(View view){
        Intent in1= new Intent(choosehardware.this,innerhardwares.class);

        startActivity(in1);
    }
    public void mobileinfo(View view){
        Intent in1= new Intent(choosehardware.this,mobileinfo.class);

        startActivity(in1);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choosehardware);
        Intent i=getIntent();
    }
}