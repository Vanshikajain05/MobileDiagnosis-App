package vanshika.myapp.mobilediagnosis;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class bt extends AppCompatActivity {

    TextView textView;
    ImageView im;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bt);
        Intent i=getIntent();


    }
public void bluetooth(View view){
    BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    textView=(TextView)findViewById(R.id.t);
    im= (ImageView)findViewById(R.id.btu);
    if (mBluetoothAdapter == null) {
        // Device does not support Bluetooth
        textView.setText("  Bluetooth is not supported!");
        im.setImageResource(R.drawable.bnot);

    } else if (!mBluetoothAdapter.isEnabled()) {
        // Bluetooth is not enabled :)
        textView.setText("Bluetooth is enabled!");
        im.setImageResource(R.drawable.benable);
    } else {
        textView.setText("Bluetooth is not enabled!");
        im.setImageResource(R.drawable.bdisable);
        // Bluetooth is enabled
    }
}

}