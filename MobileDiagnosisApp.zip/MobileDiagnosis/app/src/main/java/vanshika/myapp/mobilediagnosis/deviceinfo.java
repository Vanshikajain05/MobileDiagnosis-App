package vanshika.myapp.mobilediagnosis;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.widget.TextView;

import java.lang.reflect.Method;

public class deviceinfo extends AppCompatActivity {


    public static String getSerialNumber() {
        String serialNumber;

        try {
            Class<?> c = Class.forName("android.os.SystemProperties");
            Method get = c.getMethod("get", String.class);
            serialNumber = (String) get.invoke(c, "gsm.sn1");

            if (serialNumber.equals(""))
                serialNumber = (String) get.invoke(c, "ril.serialnumber");

            if (serialNumber.equals(""))
                serialNumber = (String) get.invoke(c, "ro.serialno");

            if (serialNumber.equals(""))
                serialNumber = (String) get.invoke(c, "sys.serialnumber");

            if (serialNumber.equals(""))
                serialNumber = Build.SERIAL;

            if (serialNumber.equals(Build.UNKNOWN))
                serialNumber = null;
        } catch (Exception e) {
            e.printStackTrace();
            serialNumber = null;
        }

        return serialNumber;
    }

    String serial = getSerialNumber();


    TextView t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13, t14, t15;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deviceinfo);
        Intent i = getIntent();

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE},PackageManager.PERMISSION_GRANTED);
        TelephonyManager tm=(TelephonyManager)this.getSystemService(Context.TELEPHONY_SERVICE);
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)!=PackageManager.PERMISSION_GRANTED){
            return;
        }
        String st=tm.getImei(0);
        String st2=tm.getImei(1);


        t1 = (TextView) findViewById(R.id.t1);
        t1 = (TextView) findViewById(R.id.t1);
        t2 = (TextView) findViewById(R.id.t2);
        t3 = (TextView) findViewById(R.id.t3);
        t4 = (TextView) findViewById(R.id.t4);
        t5 = (TextView) findViewById(R.id.t5);
        t6 = (TextView) findViewById(R.id.t6);
        t7 = (TextView) findViewById(R.id.t7);
        t8 = (TextView) findViewById(R.id.t8);
        t9 = (TextView) findViewById(R.id.t9);
        t10 = (TextView) findViewById(R.id.t10);
        t11 = (TextView) findViewById(R.id.t11);
        t12 = (TextView) findViewById(R.id.t12);
        t13 = (TextView) findViewById(R.id.t13);
        t14 = (TextView) findViewById(R.id.t14);
        t15 = (TextView) findViewById(R.id.t15);

        //Information about the current build, extracted from system properties.

        t1.setText("PRODUCT: " + Build.PRODUCT);
        t2.setText("BRAND: " + Build.BRAND);
        t3.setText("DEVICE NAME: " + Build.DEVICE);
        t4.setText("ANDROID VERSION: " + Build.VERSION.RELEASE);
        t5.setText("DISPLAY: " + Build.DISPLAY);
        t6.setText("HARDWARE: " + Build.HARDWARE);
        t7.setText("HOST: " + Build.HOST);
        t8.setText("SERIAL NUMBER: " + serial);
        t9.setText("MODEL: " + Build.MODEL);
        t10.setText("TIME: " + Build.TIME);
        t11.setText("BOARD: " + Build.BOARD);
        t12.setText("FINGERPRINT: " + Build.FINGERPRINT);
        t13.setText("MANUFACTURER: " + Build.MANUFACTURER);
        t14.setText("ID: " + Build.ID);
     t15.setText("IMEI1: "+st+"\n"+"IMEI2: "+st2);


}

}